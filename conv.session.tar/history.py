# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Wed Jan 21 13:35:01 2015)---
runfile('C:/Users/Efrem/.spyder2/titanic1.py', wdir='C:/Users/Efrem/.spyder2')

##---(Wed Jan 21 15:00:34 2015)---
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/titanic1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
data
print data
zipfian1
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
python zipfian1
ls
ipython zipfian1
python zipfian1
run zipfian1
debugfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/hello.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
4 % 2
4 % 3
range(0,3)
%reset
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
dir()
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/hello.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
hello()
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
s
print s
specials = [3,5]
print specials
for s in specials:    print s    
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
debugfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
range(1,4)
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/zipfian1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
%reset
exit

##---(Thu Jan 22 14:11:37 2015)---
data[0::,4]
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/titanic1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
data[0::,4]
data[0::,2].astype(np.float)
data[::,0]
data[1::]
data[1,::]
data[1,:]
data[0,:]
data
data[1]
data[0]
data[0,:]
data[0,::]
data[0::,0]
data[0::,1]
data[0::,2]
data[0::,3]
debugfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/titanic1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/titanic1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
data[0::,4]
data[0::,4] == "male"
data[0::,4] == int("male")
data[0::,4] == float("male")
data[0::,4] == "male"
int(data[0::,4] == "male")
data[0::,4] == "male" 
(data[0::,4] == "male").astype(np.float)
(data[0::,4] == "male").astype(np.int)
clear
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/titanic1.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
runfile('C:/Users/Efrem/Dropbox/Kaggle - Titanic/titanic2.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')

##---(Sat Jan 24 18:37:23 2015)---
exit

##---(Tue Jan 27 13:58:11 2015)---
runfile('C:/Users/Efrem/Dropbox/school/research/bArnoldi/pyarnoldi.py', wdir='C:/Users/Efrem/Dropbox/Kaggle - Titanic')
a = array([[1,2,3],[4,5,6],[7,8,9]])
import numpy
a = array([[1,2,3],[4,5,6],[7,8,9]])
import numpy as np
a = np.array([[1,2,3],[4,5,6],[7,8,9]])
a
a.print()
a
print a
print a[1]
print a[:,1]
print a[:,0]
print a[:0]
print a[0]
print a[1]
print a[2]
print a[:,1]
print a[:,2]
print a[:,3]
print a[:,2]
print a[:,0]
a = 'hello'
print a
print a*2
a += a
a -= a
a -= 'hello'
a
a = 'hello'
d = {}
exit()